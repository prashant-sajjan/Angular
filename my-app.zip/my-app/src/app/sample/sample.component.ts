import { Component, OnInit } from '@angular/core';
import { DragulaService } from 'ng2-dragula';

@Component({
  selector: 'app-sample',
  templateUrl: './sample.component.html',
  styleUrls: ['./sample.component.css']
})
export class SampleComponent implements OnInit {
  msg = '';

  items = [
    'Candlestick',
    'Dagger',
    'Revolver',
    'Rope',
    'Pipe',
    'Wrench'
  ];
  constructor(private dragulaService: DragulaService) { 
    dragulaService.createGroup("VAMPIRES", {
      removeOnSpill: true
    });
  }

  ngOnInit(): void {
    this.dragulaService
      .drag('bag-items')
      .subscribe(value => {
        this.msg = `Dragging the ${ value[1].innerText }!`;
      });

    this.dragulaService
      .drop('bag-items')
      .subscribe(value => {
        this.msg = `Dropped the ${ value[1].innerText }!`;

        setTimeout(() => {
          this.msg = '';
        }, 1000);
      });
  }

  public addNewItem() {
    this.items.push('New Item');
  }
}
